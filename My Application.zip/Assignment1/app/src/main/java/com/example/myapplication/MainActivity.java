package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements Fragment2.OnContinueClickListener {

    private ActivityMainBinding binding;

    private int currentFragment = 1;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Fragment1 fragment1 = Fragment1.newInstance(null, null);
        Fragment2 fragment2 = new Fragment2();
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment_container, fragment1)
                .commit();

        binding.buttonContinue.setOnClickListener(view -> {
            if (currentFragment == 1) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment2)
                        .addToBackStack(null)
                        .commit();
                currentFragment = 2;
            } else {
                if (!TextUtils.isEmpty(
                        Fragment2.fragment2Binding.editText.getText().toString())) {

                    // قراءة البيانات من Fragment2
                    String name = Fragment2.fragment2Binding.editText.getText().toString();
                    String email = Fragment2.fragment2Binding.emailId.getText().toString();
                    String gender = Fragment2.fragment2Binding.genderId.getText().toString();
                    String age = Fragment2.fragment2Binding.ageId.getText().toString();

                    Toast.makeText(
                                    getApplicationContext(),
                                    name,
                                    Toast.LENGTH_SHORT)
                            .show();


                    onContinueClick(name, email, gender, age);

                } else {
                    Toast.makeText(
                                    getApplicationContext(),
                                    "Enter name!",
                                    Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });
    }


    @Override
    public void onContinueClick(String name) {
    }
    @Override
    public void onContinueClick(String name, String email, String gender, String age){
        Bundle bundle = new Bundle();
        bundle.putString("name", name);
        bundle.putString("email", email);
        bundle.putString("gender", gender);
        bundle.putString("age", age);

        Fragment3 fragment3 = new Fragment3();
        fragment3.setArguments(bundle);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment3)
                .addToBackStack(null)
                .commit();
    }
}