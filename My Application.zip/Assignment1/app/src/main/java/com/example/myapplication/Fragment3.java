package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.myapplication.databinding.Fragment3Binding;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class Fragment3 extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    // TODO: Rename and change types of parameters
    private Fragment3Binding binding;

    private String name;

    private String email;
    private String gender;
    private String age;
    public Fragment3() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *

     * @return A new instance of fragment Fragment3.
     */
    // TODO: Rename and change types and number of parameters


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = Fragment3Binding.inflate(inflater, container, false);

        if (getArguments() != null) {
            name = getArguments().getString("name");

            email = getArguments().getString("email");
            gender = getArguments().getString("gender");
            age = getArguments().getString("age");
            binding.textId.setText(
                    "Name: " + name + "\nEmail: " + email + "\nGender: " + gender + "\nAge: " + age
            );
        }

        binding.checkBoxId.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    if (isChecked) {
                        binding.buttonId.setEnabled(true);
                        binding.buttonId.setText("Finish");
                    } else {
                        binding.buttonId.setEnabled(false);
                        binding.buttonId.setText("Continue");
                    }
                });

        return binding.getRoot();
    }
}